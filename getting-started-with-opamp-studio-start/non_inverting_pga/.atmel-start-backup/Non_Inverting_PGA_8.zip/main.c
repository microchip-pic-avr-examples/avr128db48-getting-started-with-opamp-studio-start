#include <atmel_start.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "adc.h"
#include "rtc.h"
#include "dac.h"
#include "usart.h"
#include "rtc_application.h"


void void_setup_interrupt_routines();


int main(void)
{    
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    ADC_0_register_callback(&ADC_cb);
    
    sin_wave_table_init();
    
    set_up_data_stream();
    
    DAC0_SineWaveTimer_enable();
    ADC0_SampleTimer_enable();
    
    RTC_enable();
    
    sei();
     
	/* Replace with your application code */
	while (1) {
	}
}
