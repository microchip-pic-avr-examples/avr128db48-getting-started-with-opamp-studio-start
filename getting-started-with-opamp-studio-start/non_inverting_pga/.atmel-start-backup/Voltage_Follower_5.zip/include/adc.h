/*
 * adc.h
 *
 * Created: 16-Jun-20 10:57:45
 *  Author: M52422
 */ 


#ifndef ADC_H_
#define ADC_H_

#include "adc_basic.h"
#include "tcb.h"
#include "usart.h"


void ADC_cb();

#endif /* ADC_H_ */