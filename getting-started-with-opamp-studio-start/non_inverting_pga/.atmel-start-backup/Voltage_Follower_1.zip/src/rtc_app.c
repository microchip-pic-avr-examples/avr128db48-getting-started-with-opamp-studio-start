/*
 * rtc_app.c
 *
 * Created: 16-Jun-20 11:24:52
 *  Author: M52422
 */ 

#include "rtc_app.h"


void rtc_cb()
{
    LED0_toggle_level();
}