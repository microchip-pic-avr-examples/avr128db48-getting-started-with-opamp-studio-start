/*
 * adc.c
 *
 * Created: 16-Jun-20 10:57:20
 *  Author: M52422
 */ 

#include "adc.h"

extern data_visualizer data_stream;


void ADC_0_cb()
{
    data_stream.data_available = 1;
    data_stream.opampVAl = ADC_0_get_conversion_result();
    DS_sendData();
}

void TCB1_cb()
{
    if(data_stream.data_available == 0) {
        ADC_0_start_conversion();
    }
    
}