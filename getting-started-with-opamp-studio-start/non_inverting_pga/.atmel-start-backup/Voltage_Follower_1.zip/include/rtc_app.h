/*
 * rtc_app.h
 *
 * Created: 16-Jun-20 11:25:16
 *  Author: M52422
 */ 


#ifndef RTC_APP_H_
#define RTC_APP_H_


#include "atmel_start_pins.h"


void rtc_cb();


#endif /* RTC_APP_H_ */