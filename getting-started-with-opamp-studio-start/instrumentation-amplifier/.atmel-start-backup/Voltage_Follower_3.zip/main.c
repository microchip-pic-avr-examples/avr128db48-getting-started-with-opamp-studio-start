#include <atmel_start.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "adc.h"
#include "rtc.h"
#include "dac.h"
#include "usart.h"


void void_setup_interrupt_routines();


int main(void)
{    
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
    
    ADC_0_register_callback(&ADC_cb);
    
    sin_wave_table_init();
    
    set_up_data_stream();
    
    TCB0.CTRLA |= TCB_ENABLE_bm; // Enable TCB0
    TCB1.CTRLA |= TCB_ENABLE_bm; // Enable TCB1 
    
    while(RTC.STATUS & RTC_CTRLABUSY_bm){
    } //Wait for RTC CTRAL to be unsynchronized
    RTC.CTRLA |= RTC_RTCEN_bm; //Enable RTC
    
    sei();
     
	/* Replace with your application code */
	while (1) {
	}
}
