#include <atmel_start.h>

#include "adc.h"
#include "rtc.h"
#include "dac.h"
#include "usart.h"


void void_setup_interrupt_routines();


int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

     
	/* Replace with your application code */
	while (1) {
	}
}

void_setup_interrupt_routines()
{
    ADC_0_register_callback(&ADC_cb);
    TCB_1_register
}